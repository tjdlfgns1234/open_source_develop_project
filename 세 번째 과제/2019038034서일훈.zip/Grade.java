/*****************************

* 프로그램명: 성적관리 프로그램(Grade)

* 작성자 :  2019038034 서일훈

* 작성일 :   20.09.25

*프로그램 설명 :  키보드로 부터 5명의 학번, 이름, 국어, 영어, 수학, C언어를 입력받아 
                총점 평균 학점을 계산하여 출력하는 프로그램

*********************************/

import java.util.*;

class Student{
    int stdnum;
    String name;
    int korean;
    int english;
    int math;
    int clan;
    int sum;
    double mean;
    String grade;

    public void GetStdInfo() {
        Scanner scanner = new Scanner(System.in);
        this.stdnum = scanner.nextInt();
        this.name = scanner.next();
        this.korean = scanner.nextInt();
        this.english = scanner.nextInt();
        this.math = scanner.nextInt();
        this.clan = scanner.nextInt();

        this.sum = korean + english + math + clan;
        this.mean = sum/4.0;
        this.GetGrade(mean);
    }
    private void GetGrade(double mean)
    {
        if(mean>=90.0)
            this.grade = "A";
        else if(mean>=80.0)
            this.grade = "B";
        else if(mean>=70.0)
            this.grade = "C";
        else if(mean>=60.0)
            this.grade = "D";
        else
            this.grade = "F";
    }
    public void PrintInfo(){
        System.out.print( this.stdnum + "    " + this.name + "        " +this.korean + "      "+ this.english );
        System.out.println( "      "+ this.math + "      " +this.clan + "      " + this.sum + "      " + this.mean + "      " + this.grade);
    }




}



public class Grade{

    
    public static void main(String args[])
    {
        final int stdsize = 5;
        Student std[] = new Student[stdsize];

        System.out.println("각 학생들의 학번, 이름, 국어, 영어, 수학, C언어 순으로 입력해주세요.");
        for(int i = 0 ; i < stdsize;i++)
        {
            System.out.println(i+1+" 번쨰 학생의 정보");
            std[i] = new Student();
            std[i].GetStdInfo();
        }
        System.out.println("\t"+"\t" +"성적관리 프로그램 ");
        System.out.println("__________________________________________________________________________________");
        System.out.println(" 학번          이름          국어    영어    수학     C언어    총점     평균    학점");
        for(int i = 0 ; i < stdsize;i++)
        {
            std[i].PrintInfo();
        }
        System.out.println("__________________________________________________________________________________");
    }

}

